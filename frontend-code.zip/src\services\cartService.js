import api from './api'

export const cartService = {
  get: () => api.get('/cart').then((r) => r.data),
  add: (productId, quantity = 1) => api.post('/cart/items', { product_id: productId, quantity }).then((r) => r.data),
  update: (productId, quantity) => api.put(`/cart/items/${productId}`, { quantity }).then((r) => r.data),
  remove: (productId) => api.delete(`/cart/items/${productId}`).then((r) => r.data),
  clear: () => api.delete('/cart').then((r) => r.data),
  wishlist: () => api.get('/wishlist').then((r) => r.data),
  addWishlist: (productId) => api.post('/wishlist/items', { product_id: productId }).then((r) => r.data),
  removeWishlist: (productId) => api.delete(`/wishlist/items/${productId}`).then((r) => r.data),
}
