export default function Loader({ label = 'Finding the good stuff…' }) {
  return <div className="loader-wrap" role="status"><span className="spinner" />{label}</div>
}
