import { ArrowRight } from 'lucide-react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { user, login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  if (user) return <Navigate to="/profile" replace />
  async function submit(event) {
    event.preventDefault()
    setBusy(true); setError('')
    try { await login(form.email, form.password); navigate(location.state?.from?.pathname || '/profile', { replace: true }) }
    catch (err) { setError(err?.response?.data?.detail || 'We couldn’t sign you in. Check your details and try again.') }
    finally { setBusy(false) }
  }
  return <div className="auth-page page-shell"><div className="auth-art"><img src="https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?auto=format&fit=crop&w=1100&q=85" alt="Soft light across an inviting room" /><div><span className="eyebrow">WELCOME BACK</span><h2>Good to see<br />you again.</h2></div></div><form className="auth-form" onSubmit={submit}><span className="eyebrow">YOUR CORNER OF MORROW</span><h1>Come on in.</h1><p>Sign in to pick up right where you left off.</p>{error && <div className="form-error" role="alert">{error}</div>}<label>Email address<input type="email" autoComplete="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label><label>Password<input type="password" autoComplete="current-password" required minLength="8" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></label><button className="button button-dark auth-submit" disabled={busy}>{busy ? 'Signing you in…' : 'Sign in'} <ArrowRight size={16} /></button><p className="auth-switch">New around here? <Link to="/register">Create an account</Link></p></form></div>
}
