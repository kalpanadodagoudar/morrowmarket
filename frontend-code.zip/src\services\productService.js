import api from './api'

export const productService = {
  list: (params = {}) => api.get('/products', { params }).then((r) => r.data),
  get: (id) => api.get(`/products/${id}`).then((r) => r.data),
  search: (params) => api.get('/products/search', { params }).then((r) => r.data),
  category: (name, params = {}) => api.get(`/products/category/${encodeURIComponent(name)}`, { params }).then((r) => r.data),
}
