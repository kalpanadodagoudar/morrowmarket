import { Heart, Menu, ShoppingBag, UserRound, X } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'
import SearchBar from './SearchBar'

export default function Navbar() {
  const { user, logout } = useAuth()
  const { count, wishlist } = useCart()
  const [menuOpen, setMenuOpen] = useState(false)
  const navigate = useNavigate()

  return (
    <header className="site-header">
      <div className="header-main page-shell">
        <button className="icon-button mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'}>{menuOpen ? <X /> : <Menu />}</button>
        <Link to="/" className="brand" aria-label="Morrow Market home"><span className="brand-mark">m</span><span>morrow<span className="brand-light">market</span></span></Link>
        <SearchBar className="header-search" />
        <nav className="header-actions" aria-label="Account and shopping">
          {user ? (
            <div className="account-menu">
              <Link to="/profile" className="header-link"><UserRound size={19} /><span>Hi, {user.name.split(' ')[0]}</span></Link>
              <button className="quiet-link logout-button" onClick={() => { logout(); navigate('/') }}>Sign out</button>
            </div>
          ) : <Link to="/login" className="header-link"><UserRound size={19} /><span>Sign in</span></Link>}
          <Link to="/wishlist" className="header-link header-icon-link" aria-label={`Wishlist, ${wishlist.length} items`}><Heart size={20} /><span className="desktop-only">Saved</span>{wishlist.length > 0 && <b className="count-badge">{wishlist.length}</b>}</Link>
          <Link to="/cart" className="header-link header-icon-link" aria-label={`Shopping bag, ${count} items`}><ShoppingBag size={20} /><span className="desktop-only">Bag</span>{count > 0 && <b className="count-badge">{count}</b>}</Link>
        </nav>
      </div>
      {menuOpen && <div className="mobile-search page-shell"><SearchBar /></div>}
    </header>
  )
}
