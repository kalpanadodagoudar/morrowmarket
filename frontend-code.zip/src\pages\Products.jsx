import { SlidersHorizontal } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useSearchParams, useParams } from 'react-router-dom'
import ErrorMessage from '../components/ErrorMessage'
import Loader from '../components/Loader'
import ProductGrid from '../components/ProductGrid'
import { productService } from '../services/productService'

export default function Products() {
  const { category: routeCategory } = useParams()
  const [params, setParams] = useSearchParams()
  const [result, setResult] = useState({ items: [], total: 0, pages: 1 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filtersOpen, setFiltersOpen] = useState(false)
  const query = params.get('q') || ''
  const category = routeCategory ? decodeURIComponent(routeCategory) : (params.get('category') || '')

  async function load() {
    setLoading(true)
    setError('')
    try {
      const filters = {
        q: query || undefined,
        category: category || undefined,
        min_price: params.get('min_price') || undefined,
        max_price: params.get('max_price') || undefined,
        min_rating: params.get('min_rating') || undefined,
        sort: params.get('sort') || 'featured',
        page: params.get('page') || 1,
        limit: 12,
      }
      setResult(await productService.list(filters))
    } catch (err) {
      setError(err?.response?.data?.detail || 'We couldn’t find the collection right now.')
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [query, category, params.toString()])
  function setFilter(key, value) {
    const next = new URLSearchParams(params)
    if (value) next.set(key, value); else next.delete(key)
    next.delete('page')
    setParams(next)
  }
  const heading = query ? `Results for “${query}”` : category || 'All the good stuff'

  return (
    <div className="page-shell catalog-page">
      <div className="catalog-heading"><div><span className="eyebrow">THE MORROW COLLECTION</span><h1>{heading}</h1><p>{result.total} thoughtful finds, and counting.</p></div><button className="filter-toggle" onClick={() => setFiltersOpen(!filtersOpen)}><SlidersHorizontal size={17} /> {filtersOpen ? 'Hide filters' : 'Filters & sort'}</button></div>
      <div className="catalog-layout">
        <aside className={`filter-panel ${filtersOpen ? 'filter-panel-open' : ''}`}>
          <div className="filter-title">Make it yours <SlidersHorizontal size={16} /></div>
          <label>Category<select value={category} onChange={(e) => setFilter('category', e.target.value)}><option value="">All departments</option><option>Home & Living</option><option>Tech</option><option>Style</option><option>Pantry</option><option>Wellness</option></select></label>
          <label>Price range<div className="price-inputs"><input aria-label="Minimum price" type="number" min="0" placeholder="$ Min" value={params.get('min_price') || ''} onChange={(e) => setFilter('min_price', e.target.value)} /><input aria-label="Maximum price" type="number" min="0" placeholder="$ Max" value={params.get('max_price') || ''} onChange={(e) => setFilter('max_price', e.target.value)} /></div></label>
          <label>Customer rating<select value={params.get('min_rating') || ''} onChange={(e) => setFilter('min_rating', e.target.value)}><option value="">Any rating</option><option value="4.5">4.5 & up</option><option value="4">4 & up</option><option value="3">3 & up</option></select></label>
          <label>Sort by<select value={params.get('sort') || 'featured'} onChange={(e) => setFilter('sort', e.target.value)}><option value="featured">Featured</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option><option value="rating">Top rated</option><option value="discount">Biggest savings</option><option value="newest">Just in</option></select></label>
          <button className="clear-filters" onClick={() => setParams(query ? { q: query } : {})}>Clear all filters</button>
        </aside>
        <div className="catalog-results">
          {loading ? <Loader /> : error ? <ErrorMessage message={error} onRetry={load} /> : <><ProductGrid products={result.items} />{result.pages > 1 && <div className="pagination"><button disabled={Number(params.get('page') || 1) <= 1} onClick={() => setFilter('page', String(Number(params.get('page') || 1) - 1))}>Previous</button><span>Page {result.page} of {result.pages}</span><button disabled={Number(params.get('page') || 1) >= result.pages} onClick={() => setFilter('page', String(Number(params.get('page') || 1) + 1))}>Next</button></div>}</>}
        </div>
      </div>
    </div>
  )
}
