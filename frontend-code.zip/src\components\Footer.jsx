import { ArrowUpRight, Instagram, Mail } from 'lucide-react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="page-shell footer-main">
        <div className="footer-brand-col">
          <Link to="/" className="brand footer-brand"><span className="brand-mark">m</span><span>morrow<span className="brand-light">market</span></span></Link>
          <p>Good things, found.<br />Thoughtful picks for the life you’re living.</p>
          <a className="social-link" href="https://instagram.com" target="_blank" rel="noreferrer"><Instagram size={17} /> Come say hi <ArrowUpRight size={14} /></a>
        </div>
        <div className="footer-links"><h3>Explore</h3><Link to="/products">All finds</Link><Link to="/category/Tech">Tech</Link><Link to="/category/Style">Style</Link><Link to="/category/Home%20%26%20Living">Home & Living</Link></div>
        <div className="footer-links"><h3>Here to help</h3><Link to="/profile">Your account</Link><Link to="/orders">Order history</Link><Link to="/cart">Your bag</Link><a href="mailto:hello@morrow.market">Get in touch</a></div>
        <div className="footer-newsletter"><h3>A note from us</h3><p>New finds, small joys, and the occasional very good deal.</p><a href="mailto:hello@morrow.market" className="newsletter-link"><Mail size={17} /> hello@morrow.market <ArrowUpRight size={14} /></a></div>
      </div>
      <div className="page-shell footer-bottom"><span>© {new Date().getFullYear()} Morrow Market</span><span>Made for the everyday, with a little extra care.</span></div>
    </footer>
  )
}
