import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { useAuth } from './AuthContext'
import { cartService } from '../services/cartService'

const CartContext = createContext(null)

export function CartProvider({ children }) {
  const { user } = useAuth()
  const [items, setItems] = useState([])
  const [wishlist, setWishlist] = useState([])
  const [error, setError] = useState('')

  const refresh = useCallback(async () => {
    if (!user) {
      setItems([])
      setWishlist([])
      return
    }
    try {
      const [cart, saved] = await Promise.all([cartService.get(), cartService.wishlist()])
      setItems(cart.items || [])
      setWishlist(saved.items || [])
      setError('')
    } catch (err) {
      setError(err?.response?.data?.detail || 'Could not load your bag. Please refresh.')
    }
  }, [user])

  useEffect(() => { refresh() }, [refresh])

  const value = useMemo(() => ({
    items,
    wishlist,
    error,
    count: items.reduce((total, item) => total + item.quantity, 0),
    subtotal: items.reduce((total, item) => total + item.product.price * item.quantity, 0),
    refresh,
    async add(productId, quantity = 1) {
      await cartService.add(productId, quantity)
      await refresh()
    },
    async update(productId, quantity) {
      await cartService.update(productId, quantity)
      await refresh()
    },
    async remove(productId) {
      await cartService.remove(productId)
      await refresh()
    },
    async toggleWishlist(productId) {
      const existing = wishlist.some((item) => item.product_id === productId)
      if (existing) await cartService.removeWishlist(productId)
      else await cartService.addWishlist(productId)
      await refresh()
    },
    async clear() {
      await cartService.clear()
      await refresh()
    },
  }), [items, wishlist, error, refresh])

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) throw new Error('useCart must be used within CartProvider')
  return context
}
