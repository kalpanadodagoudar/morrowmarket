import { ArrowLeft, Heart, Minus, Plus, ShieldCheck, ShoppingBag, Star, Truck } from 'lucide-react'
import { Link, useParams, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { productService } from '../services/productService'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'
import Loader from '../components/Loader'
import ErrorMessage from '../components/ErrorMessage'

export default function ProductDetails() {
  const { id } = useParams()
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [quantity, setQuantity] = useState(1)
  const [notice, setNotice] = useState('')
  const { user } = useAuth()
  const { add, wishlist, toggleWishlist } = useCart()
  const navigate = useNavigate()

  async function load() {
    setLoading(true)
    try { setProduct(await productService.get(id)); setError('') }
    catch (err) { setError(err?.response?.data?.detail || 'We couldn’t find this lovely thing.') }
    finally { setLoading(false) }
  }
  useEffect(() => { load() }, [id])

  async function run(action) {
    if (!user) return navigate('/login')
    try {
      if (action === 'cart') { await add(product.id, quantity); setNotice('Added to your bag. Good choice.') }
      else { await toggleWishlist(product.id); setNotice('Your saved finds are up to date.') }
    } catch (err) { setNotice(err?.response?.data?.detail || 'That didn’t work. Please try again.') }
  }

  if (loading) return <div className="page-shell detail-loading"><Loader /></div>
  if (error) return <div className="page-shell detail-loading"><ErrorMessage message={error} onRetry={load} /></div>
  if (!product) return null
  const saved = wishlist.some((item) => item.product_id === product.id)
  return (
    <div className="page-shell detail-page">
      <Link to="/products" className="back-link"><ArrowLeft size={16} /> Back to all finds</Link>
      <div className="detail-layout">
        <div className="detail-image"><img src={product.image} alt={product.name} /><span className="detail-image-caption">A Morrow favorite</span></div>
        <div className="detail-copy"><span className="eyebrow">{product.brand || product.category}</span><h1>{product.name}</h1><div className="detail-rating"><span className="rating-pill"><Star size={13} fill="currentColor" /> {Number(product.rating).toFixed(1)}</span><span>{product.reviews_count} lovely reviews</span></div>
          <div className="detail-price"><strong>${Number(product.price).toFixed(2)}</strong>{product.original_price > product.price && <><del>${Number(product.original_price).toFixed(2)}</del><span>{product.discount}% off</span></>}</div>
          <p className="detail-description">{product.description}</p>
          <div className="stock-note">{product.stock > 0 ? 'In stock and ready to make your day' : 'Currently out of stock'}</div>
          <div className="detail-actions"><div className="quantity-stepper"><button onClick={() => setQuantity(Math.max(1, quantity - 1))} aria-label="Decrease quantity"><Minus size={15} /></button><span>{quantity}</span><button onClick={() => setQuantity(Math.min(product.stock || 1, quantity + 1))} aria-label="Increase quantity"><Plus size={15} /></button></div><button className="button button-dark detail-add" disabled={!product.stock} onClick={() => run('cart')}><ShoppingBag size={17} /> Add to bag</button><button className={`detail-save ${saved ? 'is-saved' : ''}`} onClick={() => run('wishlist')} aria-label={saved ? 'Remove from wishlist' : 'Save to wishlist'}><Heart size={19} fill={saved ? 'currentColor' : 'none'} /></button></div>
          {notice && <p className="detail-notice" role="status">{notice}</p>}
          <div className="delivery-points"><p><Truck size={18} /> Free delivery on orders over $75</p><p><ShieldCheck size={18} /> Easy returns, no hard feelings</p></div>
          {product.specifications && Object.keys(product.specifications).length > 0 && <div className="specs"><h3>The little details</h3>{Object.entries(product.specifications).map(([key, value]) => <div key={key}><span>{key}</span><strong>{String(value)}</strong></div>)}</div>}
        </div>
      </div>
    </div>
  )
}
