import { ArrowRight, Heart, ShoppingBag, Star } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'

export default function ProductCard({ product }) {
  const { user } = useAuth()
  const { add, wishlist, toggleWishlist } = useCart()
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const navigate = useNavigate()
  const saved = wishlist.some((item) => item.product_id === product.id)

  async function handle(action) {
    if (!user) {
      navigate('/login')
      return
    }
    setBusy(true)
    setMessage('')
    try {
      if (action === 'cart') {
        await add(product.id)
        setMessage('Added to your bag')
      } else await toggleWishlist(product.id)
    } catch (error) {
      setMessage(error?.response?.data?.detail || 'That didn’t work. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <article className="product-card">
      <div className="product-image-wrap">
        <Link to={`/products/${product.id}`} className="product-image-link" aria-label={`View ${product.name}`}>
          <img src={product.image} alt={product.name} loading="lazy" />
        </Link>
        {product.discount > 0 && <span className="product-discount">{product.discount}% off</span>}
        <button className={`wishlist-button ${saved ? 'is-saved' : ''}`} onClick={() => handle('wishlist')} aria-label={saved ? 'Remove from wishlist' : 'Add to wishlist'} disabled={busy}><Heart size={18} fill={saved ? 'currentColor' : 'none'} /></button>
      </div>
      <div className="product-info">
        <p className="product-brand">{product.brand || product.category}</p>
        <Link to={`/products/${product.id}`} className="product-title">{product.name}</Link>
        <div className="product-rating"><span className="rating-pill"><Star size={12} fill="currentColor" /> {Number(product.rating).toFixed(1)}</span><span>({product.reviews_count || 0})</span></div>
        <div className="product-prices"><strong>${Number(product.price).toFixed(2)}</strong>{product.original_price > product.price && <><del>${Number(product.original_price).toFixed(2)}</del><span className="save-label">Save {product.discount}%</span></>}</div>
        <button className="add-button" onClick={() => handle('cart')} disabled={busy || product.stock < 1}><ShoppingBag size={15} />{product.stock < 1 ? 'Out of stock' : busy ? 'One moment…' : 'Add to bag'}</button>
        <Link to={`/products/${product.id}`} className="product-details-link">View details <ArrowRight size={13} /></Link>
        {message && <span className="product-feedback" role="status">{message}</span>}
      </div>
    </article>
  )
}
