export default function ErrorMessage({ message, onRetry }) {
  return (
    <div className="error-message" role="alert">
      <span>{message || 'We couldn’t load this just now.'}</span>
      {onRetry && <button className="text-button" onClick={onRetry}>Try again</button>}
    </div>
  )
}
