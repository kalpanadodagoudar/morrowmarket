import { ArrowRight } from 'lucide-react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const { user, register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  if (user) return <Navigate to="/profile" replace />
  async function submit(event) {
    event.preventDefault(); setBusy(true); setError('')
    try { await register(form); navigate('/profile', { replace: true }) }
    catch (err) { setError(err?.response?.data?.detail || 'We couldn’t create your account. Please try again.') }
    finally { setBusy(false) }
  }
  return <div className="auth-page page-shell"><div className="auth-art register-art"><img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1100&q=85" alt="A thoughtfully arranged home" /><div><span className="eyebrow">A GOOD THING STARTS HERE</span><h2>Find your<br />kind of good.</h2></div></div><form className="auth-form" onSubmit={submit}><span className="eyebrow">MAKE YOURSELF AT HOME</span><h1>Let’s make it yours.</h1><p>A few details and you’re in. No fuss.</p>{error && <div className="form-error" role="alert">{error}</div>}<label>Your name<input type="text" autoComplete="name" required minLength="2" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label><label>Email address<input type="email" autoComplete="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label><label>Password<input type="password" autoComplete="new-password" required minLength="8" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /><span className="field-hint">At least 8 characters, please.</span></label><button className="button button-dark auth-submit" disabled={busy}>{busy ? 'Making your account…' : 'Create my account'} <ArrowRight size={16} /></button><p className="auth-switch">Already one of us? <Link to="/login">Sign in</Link></p></form></div>
}
