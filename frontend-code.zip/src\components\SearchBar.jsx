import { Search, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'

export default function SearchBar({ className = '' }) {
  const [params] = useSearchParams()
  const [query, setQuery] = useState(params.get('q') || '')
  const navigate = useNavigate()
  useEffect(() => setQuery(params.get('q') || ''), [params])

  function submit(event) {
    event.preventDefault()
    const search = query.trim()
    navigate(search ? `/products?q=${encodeURIComponent(search)}` : '/products')
  }

  return (
    <form className={`search-form ${className}`} onSubmit={submit} role="search">
      <Search size={19} aria-hidden="true" />
      <input aria-label="Search products" placeholder="Search for something lovely…" value={query} onChange={(event) => setQuery(event.target.value)} />
      {query && <button type="button" className="search-clear" aria-label="Clear search" onClick={() => setQuery('')}><X size={16} /></button>}
      <button className="search-submit" type="submit">Search</button>
    </form>
  )
}
