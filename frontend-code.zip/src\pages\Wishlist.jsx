import { Heart } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'
import ProductGrid from '../components/ProductGrid'
import ErrorMessage from '../components/ErrorMessage'

export default function Wishlist() {
  const { user } = useAuth()
  const { wishlist, error } = useCart()
  return <div className="page-shell catalog-page"><div className="page-title"><span className="eyebrow">THE THINGS THAT CAUGHT YOUR EYE</span><h1>Your saved finds</h1></div>{error && <ErrorMessage message={error} />}{!user ? <div className="empty-state"><Heart size={30} /><h3>Keep your favorites close</h3><p>Sign in to save finds for later.</p><Link to="/login" className="button button-dark">Sign in</Link></div> : wishlist.length ? <ProductGrid products={wishlist.map((item) => item.product)} /> : <div className="empty-state"><Heart size={30} /><h3>A space for the things you love</h3><p>Tap the little heart on any find to save it here.</p><Link to="/products" className="button button-dark">Explore the collection</Link></div>}</div>
}
