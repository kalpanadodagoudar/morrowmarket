import { ArrowLeft } from 'lucide-react'
import { Link } from 'react-router-dom'

export default function NotFound() {
  return <div className="not-found page-shell"><span className="eyebrow">A LITTLE DETOUR</span><h1>Well, this is<br /><em>unexpected.</em></h1><p>We couldn’t find the page you were looking for. Let’s get you somewhere good.</p><Link to="/" className="button button-dark"><ArrowLeft size={16} /> Back to Morrow</Link></div>
}
