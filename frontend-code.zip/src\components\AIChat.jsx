import { Bot, Send, Sparkles, X } from 'lucide-react'
import { useState } from 'react'
import api, { getApiError } from '../services/api'

export default function AIChat() {
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [messages, setMessages] = useState([{ role: 'assistant', content: 'Hi there! Tell me what you’re looking for, and I’ll help you find a good fit.' }])

  async function send(event) {
    event.preventDefault()
    const prompt = input.trim()
    if (!prompt || sending) return
    setMessages((items) => [...items, { role: 'user', content: prompt }])
    setInput('')
    setSending(true)
    try {
      const { data } = await api.post('/assistant/chat', { message: prompt })
      setMessages((items) => [...items, { role: 'assistant', content: data.reply }])
    } catch (error) {
      setMessages((items) => [...items, { role: 'assistant', content: getApiError(error, 'I can’t reach the shopping assistant right now. Please try again shortly.') }])
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="ai-chat">
      {open && <section className="chat-panel" aria-label="Morrow shopping assistant">
        <div className="chat-head"><div className="chat-avatar"><Sparkles size={17} /></div><div><strong>A little help?</strong><span>Your Morrow shopping guide</span></div><button className="chat-close" onClick={() => setOpen(false)} aria-label="Close chat"><X size={18} /></button></div>
        <div className="chat-messages" aria-live="polite">{messages.map((message, index) => <p key={`${index}-${message.role}`} className={`chat-bubble ${message.role}`}>{message.content}</p>)}{sending && <p className="chat-bubble assistant">Finding a thoughtful answer…</p>}</div>
        <form className="chat-compose" onSubmit={send}><input aria-label="Message the shopping assistant" value={input} onChange={(event) => setInput(event.target.value)} placeholder="What are you looking for?" /><button aria-label="Send message" disabled={sending || !input.trim()}><Send size={17} /></button></form>
      </section>}
      <button className={`chat-launch ${open ? 'chat-launch-open' : ''}`} onClick={() => setOpen(!open)} aria-label={open ? 'Close shopping assistant' : 'Open shopping assistant'}>{open ? <X size={20} /> : <><Bot size={19} /><span>Ask Morrow</span></>}</button>
    </div>
  )
}
