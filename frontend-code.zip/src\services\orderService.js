import api from './api'

export const orderService = {
  create: (shippingAddress) => api.post('/orders', { shipping_address: shippingAddress }).then((r) => r.data),
  list: () => api.get('/orders').then((r) => r.data),
}
