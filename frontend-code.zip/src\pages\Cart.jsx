import { ArrowRight, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useState } from 'react'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import ErrorMessage from '../components/ErrorMessage'

export default function Cart() {
  const { items, subtotal, update, remove, error } = useCart()
  const { user } = useAuth()
  const [notice, setNotice] = useState('')
  async function changeBag(action) {
    setNotice('')
    try { await action() }
    catch (err) { setNotice(err?.response?.data?.detail || 'We couldn’t update your bag. Please try again.') }
  }
  if (!user) return <div className="page-shell simple-page"><div className="empty-bag"><ShoppingBag size={34} /><span className="eyebrow">YOUR NEXT FAVORITE IS WAITING</span><h1>Your bag has a little room.</h1><p>Sign in to see the things you’ve tucked away.</p><Link to="/login" className="button button-dark">Sign in to continue <ArrowRight size={16} /></Link></div></div>
  return (
    <div className="page-shell cart-page">
      <div className="page-title"><span className="eyebrow">A GOOD LITTLE HAUL</span><h1>Your bag <span>({items.length})</span></h1></div>
      {(error || notice) && <ErrorMessage message={notice || error} />}
      {!items.length ? <div className="empty-bag"><ShoppingBag size={34} /><h2>Nothing in your bag. Yet.</h2><p>There’s plenty of good stuff to find.</p><Link to="/products" className="button button-dark">Browse the finds <ArrowRight size={16} /></Link></div> : <div className="cart-layout">
        <div className="cart-list">{items.map(({ product, quantity }) => <article className="cart-item" key={product.id}><Link to={`/products/${product.id}`} className="cart-item-image"><img src={product.image} alt={product.name} /></Link><div className="cart-item-info"><span className="product-brand">{product.brand || product.category}</span><Link to={`/products/${product.id}`} className="product-title">{product.name}</Link><strong>${Number(product.price).toFixed(2)}</strong><div className="cart-item-controls"><div className="quantity-stepper"><button onClick={() => changeBag(() => update(product.id, Math.max(1, quantity - 1)))} aria-label="Decrease quantity"><Minus size={14} /></button><span>{quantity}</span><button onClick={() => changeBag(() => update(product.id, quantity + 1))} aria-label="Increase quantity"><Plus size={14} /></button></div><button className="remove-button" onClick={() => changeBag(() => remove(product.id))}><Trash2 size={14} /> Remove</button></div></div></article>)}</div>
        <aside className="order-summary"><h2>A little summary</h2><div><span>Subtotal</span><strong>${subtotal.toFixed(2)}</strong></div><div><span>Delivery</span><strong>{subtotal >= 75 ? 'On us' : '$6.95'}</strong></div><p>{subtotal < 75 ? `You’re $${(75 - subtotal).toFixed(2)} away from free delivery.` : 'Free delivery is yours. Lovely.'}</p><div className="summary-total"><span>Total before tax</span><strong>${(subtotal + (subtotal >= 75 ? 0 : 6.95)).toFixed(2)}</strong></div><Link to="/checkout" className="button button-dark summary-checkout">On to checkout <ArrowRight size={17} /></Link><Link to="/products" className="continue-link">Keep looking around</Link></aside>
      </div>}
    </div>
  )
}
