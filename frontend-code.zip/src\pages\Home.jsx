import { ArrowDownRight, ArrowRight, MoveUpRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import ProductGrid from '../components/ProductGrid'
import Loader from '../components/Loader'
import ErrorMessage from '../components/ErrorMessage'
import { productService } from '../services/productService'

const departments = [
  { name: 'Home & Living', note: 'Make room for comfort', image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=85', category: 'Home%20%26%20Living' },
  { name: 'Tech', note: 'Smart little upgrades', image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=900&q=85', category: 'Tech' },
  { name: 'Style', note: 'The pieces you reach for', image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=900&q=85', category: 'Style' },
  { name: 'Pantry', note: 'Good things to gather around', image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=900&q=85', category: 'Pantry' },
]

export default function Home() {
  const [collections, setCollections] = useState({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  async function load() {
    setLoading(true)
    setError('')
    try {
      const [featured, electronics, fashion, grocery, deals, recommended] = await Promise.all([
        productService.list({ limit: 4, sort: 'featured' }),
        productService.list({ category: 'Tech', limit: 4 }),
        productService.list({ category: 'Style', limit: 4 }),
        productService.list({ category: 'Pantry', limit: 4 }),
        productService.list({ limit: 4, sort: 'discount' }),
        productService.list({ limit: 4, sort: 'rating' }),
      ])
      setCollections({ featured, electronics, fashion, grocery, deals, recommended })
    } catch (err) {
      setError(err?.response?.data?.detail || 'We couldn’t load the collection. Check that the Morrow API is running.')
    } finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])

  function collectionSection(kicker, title, result, category, query = '') {
    return <section className="section page-shell"><div className="section-heading"><div><span className="eyebrow">{kicker}</span><h2>{title}</h2></div><Link to={query ? `/products?${query}` : `/category/${encodeURIComponent(category)}`} className="arrow-link">Explore the edit <ArrowRight size={16} /></Link></div><ProductGrid products={result?.items || []} /></section>
  }

  return (
    <>
      <section className="hero page-shell">
        <div className="hero-copy">
          <span className="eyebrow"><span className="eyebrow-dot" /> THE EVERYDAY, ELEVATED</span>
          <h1>Find your<br /><em>little</em> something.</h1>
          <p>Useful, lovely, and a bit unexpected. Meet the things that make an ordinary day feel like yours.</p>
          <Link to="/products" className="button button-dark">Explore all finds <ArrowRight size={17} /></Link>
          <div className="hero-footnote"><span className="hero-line" /> Carefully picked, never just more stuff.</div>
        </div>
        <div className="hero-art">
          <img src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=90" alt="A calm, sunlit living space with thoughtful home objects" />
          <div className="hero-note"><span>THE SLOW SUNDAY EDIT</span><strong>Make space<br />for the good.</strong><Link to="/category/Home%20%26%20Living">Shop the edit <MoveUpRight size={15} /></Link></div>
          <span className="hero-sticker">GOOD<br />THINGS<br />LIVE HERE <ArrowDownRight size={20} /></span>
        </div>
      </section>
      <section className="trust-strip"><div className="page-shell trust-inner"><span>Thoughtfully picked</span><i>✳</i><span>Easy, lovely delivery</span><i>✳</i><span>Small joys, every day</span><i>✳</i><span>Always a human to help</span></div></section>
      <section className="section page-shell">
        <div className="section-heading"><div><span className="eyebrow">A GOOD PLACE TO START</span><h2>Meet the departments</h2></div><Link to="/products" className="arrow-link">Everything we love <ArrowRight size={16} /></Link></div>
        <div className="department-grid">{departments.map((item, index) => <Link to={`/category/${item.category}`} className={`department-card department-${index + 1}`} key={item.name}><img src={item.image} alt="" loading="lazy" /><div className="department-copy"><span>{item.note}</span><h3>{item.name}</h3></div><span className="department-arrow"><ArrowRight size={18} /></span></Link>)}</div>
      </section>
      <section className="section featured-section">
        <div className="page-shell">
          <div className="section-heading"><div><span className="eyebrow">ON OUR MINDS LATELY</span><h2>Good finds, right now</h2><p className="section-subtitle">The things our team can’t stop talking about.</p></div><Link to="/products" className="arrow-link">Shop the collection <ArrowRight size={16} /></Link></div>
          {loading ? <Loader /> : error ? <ErrorMessage message={error} onRetry={load} /> : <ProductGrid products={collections.featured?.items || []} />}
        </div>
      </section>
      {error ? null : loading ? <div className="page-shell"><Loader /></div> : <>
        {collectionSection('TECH FOR REAL LIFE', 'Electronics, made everyday', collections.electronics, 'Tech')}
        {collectionSection('A FEW GOOD PIECES', 'Fashion you’ll reach for', collections.fashion, 'Style')}
        {collectionSection('GOOD THINGS TO GATHER', 'Groceries & pantry', collections.grocery, 'Pantry')}
        {collectionSection('A LITTLE LESS, A LOT LOVELY', 'Best deals, thoughtfully found', collections.deals, '', 'sort=discount')}
        {collectionSection('PICKED WITH YOU IN MIND', 'A few more to love', collections.recommended, '', 'sort=rating')}
      </>}
      <section className="story-banner page-shell">
        <div className="story-image"><img src="https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=1000&q=85" alt="Warm and cozy details at home" loading="lazy" /></div>
        <div className="story-copy"><span className="eyebrow">A SMALLER KIND OF RETAIL</span><h2>Less scrolling.<br /><em>More finding.</em></h2><p>We believe the best things aren’t always the loudest. So we look a little closer, choose a little better, and bring you useful things with a story worth telling.</p><Link to="/products" className="text-arrow">A peek at our point of view <ArrowRight size={16} /></Link></div>
      </section>
      <section className="bottom-callout"><div className="page-shell"><span className="eyebrow">YOUR NEXT EVERYDAY FAVORITE</span><h2>It’s probably <em>in here.</em></h2><Link to="/products" className="button button-dark">Take a look <ArrowRight size={17} /></Link></div></section>
    </>
  )
}
