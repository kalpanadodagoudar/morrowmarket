import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { authService } from '../services/authService'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(Boolean(localStorage.getItem('morrow_token')))

  useEffect(() => {
    if (!localStorage.getItem('morrow_token')) return
    authService.me()
      .then(setUser)
      .catch(() => {
        localStorage.removeItem('morrow_token')
      })
      .finally(() => setLoading(false))
  }, [])

  const value = useMemo(() => ({
    user,
    loading,
    async login(email, password) {
      const result = await authService.login(email, password)
      localStorage.setItem('morrow_token', result.access_token)
      setUser(result.user)
      return result.user
    },
    async register(payload) {
      const result = await authService.register(payload)
      localStorage.setItem('morrow_token', result.access_token)
      setUser(result.user)
      return result.user
    },
    logout() {
      localStorage.removeItem('morrow_token')
      setUser(null)
    },
  }), [user, loading])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth must be used within AuthProvider')
  return context
}
