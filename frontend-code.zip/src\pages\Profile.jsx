import { ArrowRight, UserRound } from 'lucide-react'
import { Link, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Profile() {
  const { user, loading } = useAuth()
  if (loading) return <div className="page-shell detail-loading">Loading your account…</div>
  if (!user) return <Navigate to="/login" replace />
  return <div className="page-shell simple-page"><div className="profile-card"><div className="profile-avatar"><UserRound size={27} /></div><span className="eyebrow">YOUR MORROW</span><h1>Lovely to have you, {user.name.split(' ')[0]}.</h1><p>{user.email}</p><div className="profile-links"><Link to="/orders"><span>Order history</span><ArrowRight size={17} /></Link><Link to="/wishlist"><span>Saved finds</span><ArrowRight size={17} /></Link><Link to="/cart"><span>Your shopping bag</span><ArrowRight size={17} /></Link></div></div></div>
}
