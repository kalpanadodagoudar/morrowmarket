import { ArrowRight, PackageCheck } from 'lucide-react'
import { Link, Navigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { orderService } from '../services/orderService'
import { useAuth } from '../context/AuthContext'
import Loader from '../components/Loader'
import ErrorMessage from '../components/ErrorMessage'

export default function Orders() {
  const { user, loading: authLoading } = useAuth()
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  async function load() {
    setLoading(true)
    try { setOrders(await orderService.list()); setError('') }
    catch (err) { setError(err?.response?.data?.detail || 'We couldn’t load your order history.') }
    finally { setLoading(false) }
  }
  useEffect(() => { if (user) load(); else setLoading(false) }, [user])
  if (authLoading) return <div className="page-shell"><Loader /></div>
  if (!user) return <Navigate to="/login" replace />
  return <div className="page-shell catalog-page"><div className="page-title"><span className="eyebrow">GOOD THINGS ON THEIR WAY</span><h1>Your orders</h1></div>{loading ? <Loader /> : error ? <ErrorMessage message={error} onRetry={load} /> : !orders.length ? <div className="empty-state"><PackageCheck size={32} /><h3>Your story starts with a find</h3><p>Your orders will show up here, ready to revisit.</p><Link to="/products" className="button button-dark">Explore finds <ArrowRight size={16} /></Link></div> : <div className="orders-list">{orders.map((order) => <article className="order-card" key={order.id}><div className="order-card-head"><div><span className="product-brand">ORDER PLACED {new Date(order.created_at).toLocaleDateString()}</span><strong>Order #{order.id.slice(-8).toUpperCase()}</strong></div><span className={`order-status ${order.status}`}>{order.status}</span></div><div className="order-products">{order.items.map((item) => <div key={item.product_id}><img src={item.image} alt="" /><span>{item.name} × {item.quantity}</span><strong>${(item.price * item.quantity).toFixed(2)}</strong></div>)}</div><div className="order-foot"><span>Ship to: {order.shipping_address}</span><strong>Total ${Number(order.total).toFixed(2)}</strong></div></article>)}</div>}</div>
}
