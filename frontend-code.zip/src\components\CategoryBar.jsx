import { Link } from 'react-router-dom'

const categories = ['All finds', 'Home & Living', 'Tech', 'Style', 'Pantry', 'Wellness']

export default function CategoryBar() {
  return (
    <nav className="category-bar" aria-label="Shop categories">
      <div className="page-shell category-inner">
        {categories.map((category) => <Link key={category} to={category === 'All finds' ? '/products' : `/category/${encodeURIComponent(category)}`}>{category}</Link>)}
        <Link to="/products?sort=discount" className="category-deals">Little luxuries, lower prices <span>↗</span></Link>
      </div>
    </nav>
  )
}
