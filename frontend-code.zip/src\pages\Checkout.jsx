import { ArrowLeft, ArrowRight, ShieldCheck } from 'lucide-react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'
import { orderService } from '../services/orderService'

export default function Checkout() {
  const { user } = useAuth()
  const { items, subtotal, clear } = useCart()
  const [address, setAddress] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const navigate = useNavigate()
  if (!user) return <Navigate to="/login" replace />
  if (!items.length) return <div className="page-shell simple-page"><div className="empty-state"><h2>Your bag is taking a breather.</h2><Link to="/products" className="button button-dark">Find something lovely</Link></div></div>
  const shipping = subtotal >= 75 ? 0 : 6.95
  async function submit(event) {
    event.preventDefault(); setBusy(true); setError('')
    try {
      await orderService.create(address)
      await clear()
      navigate('/orders', { replace: true })
    } catch (err) { setError(err?.response?.data?.detail || 'We couldn’t place your order. Please check your details and try again.') }
    finally { setBusy(false) }
  }
  return <div className="page-shell checkout-page"><Link to="/cart" className="back-link"><ArrowLeft size={16} /> Back to your bag</Link><div className="page-title"><span className="eyebrow">JUST A FEW LITTLE DETAILS</span><h1>Let’s make it yours.</h1></div><div className="checkout-layout"><form className="checkout-form" onSubmit={submit}><h2>Where should we send the good stuff?</h2>{error && <div role="alert" className="form-error">{error}</div>}<label>Full name<input value={user.name} readOnly /></label><label>Email address<input value={user.email} readOnly /></label><label>Shipping address<textarea required minLength="8" rows="3" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Street, city, postal code, country" /></label><div className="secure-note"><ShieldCheck size={17} /> Your details are kept safe and sound.</div><button className="button button-dark auth-submit" disabled={busy}>{busy ? 'Placing your order…' : 'Place my order'} <ArrowRight size={16} /></button><p className="checkout-demo-note">Demo checkout — no payment will be collected.</p></form><aside className="order-summary checkout-summary"><h2>Your good things</h2>{items.map(({ product, quantity }) => <div className="checkout-line" key={product.id}><img src={product.image} alt="" /><div><span>{product.name}</span><small>Qty {quantity}</small></div><strong>${(product.price * quantity).toFixed(2)}</strong></div>)}<div className="summary-total"><span>Subtotal</span><strong>${subtotal.toFixed(2)}</strong></div><div><span>Delivery</span><strong>{shipping ? `$${shipping.toFixed(2)}` : 'On us'}</strong></div><div className="summary-total"><span>Total</span><strong>${(subtotal + shipping).toFixed(2)}</strong></div></aside></div></div>
}
